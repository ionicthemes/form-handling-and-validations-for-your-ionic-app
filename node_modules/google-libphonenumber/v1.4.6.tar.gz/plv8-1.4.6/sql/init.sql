-- INSTALL
SET client_min_messages = warning;
\set ECHO none
\i plv8.sql
\set ECHO all
RESET client_min_messages;
